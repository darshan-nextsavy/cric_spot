import 'package:cric_spot/core/theme/app_theme.dart';
import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:google_fonts/google_fonts.dart';

final getIt = GetIt.instance;

Future<void> main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return DynamicColorBuilder(
        builder: (ColorScheme? lightDynamic, ColorScheme? darkDynamic) {
      final bool isDynamic = false;
      final ThemeMode themeMode = ThemeMode.values[0];
      final int color = 0xFF795548;
      final Color primaryColor = Color(color);

      final String fontPreference = 'Outfit';
      final TextTheme darkTextTheme = GoogleFonts.getTextTheme(
        fontPreference,
        ThemeData.dark().textTheme,
      );
      final TextTheme lightTextTheme = GoogleFonts.getTextTheme(
        fontPreference,
        ThemeData.light().textTheme,
      );

      ColorScheme lightColorScheme;
      ColorScheme darkColorScheme;
      if (lightDynamic != null && darkDynamic != null) {
        lightColorScheme = lightDynamic.harmonized();
        darkColorScheme = darkDynamic.harmonized();
      } else {
        lightColorScheme = ColorScheme.fromSeed(
          seedColor: primaryColor,
        );
        darkColorScheme = ColorScheme.fromSeed(
          seedColor: primaryColor,
          brightness: Brightness.dark,
        );
      }

      return MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: appTheme(
            context,
            lightColorScheme,
            fontPreference,
            lightTextTheme,
            ThemeData.light().dividerColor,
            SystemUiOverlayStyle.dark),
        darkTheme: appTheme(
            context,
            darkColorScheme,
            fontPreference,
            darkTextTheme,
            ThemeData.dark().dividerColor,
            SystemUiOverlayStyle.light),
        // theme: ThemeData(
        //   colorScheme:
        //       lightDynamic ?? ColorScheme.fromSeed(seedColor: Colors.pink),
        //   useMaterial3: true,
        // ),
        // darkTheme: ThemeData(
        //     colorScheme: darkDynamic ??
        //         ColorScheme.fromSeed(
        //             seedColor: Colors.pink, brightness: Brightness.dark),
        //     useMaterial3: true),
        home: const MyHomePage(title: 'Flutter Demo Home Page'),
      );
    });
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

package com.example.cric_spot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
